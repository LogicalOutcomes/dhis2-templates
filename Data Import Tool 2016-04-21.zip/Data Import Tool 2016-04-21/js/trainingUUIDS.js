/** Property file for the dataElements and OptionCombo for trainings worksheet */

var trainingDataElement =/*Male Female*/ [[1, ["tSjq7p0s8GP", "p2ltnUHxrdI", "RVHXOtpV26H", "ywLViPPxOZl", "frdIi3Nu6WK", "rTOJ80pYrMT", "JukElm6h5g0", "OsE8bdV1UcS", "nCdhR5rAUQB", "BfcK1Valj3U", "ZvfBR9cRGTd", "aqUkFjaA87n", "FvNSAUHd2iQ", "rxYTDuC4LK4"]],
    /*Peroid month*/[2, ["e82HAoOkoZb", "Z8EulGdNikh", "qEY1M9zn6GF", "qpw9id7qdHD", "Amh8BjdYOj5", "OKvt6NdFEIz", "wdacYL5NqYM", "v3HpDtscRCF", "QEYi7sa1chh", "tOzYQsuGAql", "bVjAas44GEb", "SYjATO0ogis","yy2ZSbW8z8P","HkB8AOdZXkd"]],
    /*Period year*/  [3, ["nIE9vWSfn1L", "OnDqKSFHeXX", "gk9F0eLpxQH", "Bo1MbK3zeGa", "xjWgW4g5xSR", "GCoZ3pwoFCI", "kefq5Sh2hus", "eS2xFr9W9Hc", "RXaZoXcC10G", "UZ3QiMeXnRV", "tHeFaso2HAs", "HZsAqVWCNed","m45U7GN4BfL","IjTz6yuuUOf"]],
    /*Type of training*/[4, ["-----------", "hKqbDV90JfR", "PRUcPymqqMg", "l4oFQYkk8V0", "YMXRzepzpQN", "tvPYAxG5bWw", "zAgXatOgMD8", "-----------", "nuEJ8nc11LQ", "S1ej5VVPVDW", "A0ky3usH3di","-----------","-----------","-----------"]],
/*Comment*/ [5, ["gY4lxf4BPKX", "iFDZHaJdyMo", "UOR5eFwQt9G", "XZJWxbWg5PJ", "s4OsDM2HRgC", "oZCqOafz0Oq", "dlVXNtBUpPX", "LLr5Wv4ioFT", "mi2zSJd6GcT", "yatm10YXZjE", "bNxNmehnWMc", "cngLtpMOfta","dn1mu0i5Mos","twqw5O45Apt"]]];

//                         Firstcolum + 1    Secondcolun+2
var categoryOptionsComb = ["BO4L7pJFvEB", "zIg55R6iza0", "INgVh9IjrCz"];
var years = ["ToT21", "ToT22", "ToT23", "ToT24", "ToT25"];//row 4
var months = ["ToT09", "ToT10", "ToT11", "ToT12", "ToT13", "ToT14", "ToT15", "ToT16", "ToT17", "ToT18", "ToT19", "ToT20"];//row 3
var typeOfTrainings = ["ToT01", "ToT02", "ToT30", "ToT03", "ToT04"];//BLTR, Trabut, Both, Eversion, Resection row 5
