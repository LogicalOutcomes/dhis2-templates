/** Property file for the dataElements and OptionCombo for County Information worksheet */
ciComboCategory = "INgVh9IjrCz";
ciDataelement = [
                  "UhSGhZHC0SM","Lo0mGdwGnNr",

                  "mLDZjjq9FDq","gXdwawqMqHI",

                  "XDJANAmgRwk","htNgVefbpMV",

                  "Hk3yPavh51k","kdHAo13L3S7",

                  "DQE9SMlanMy","bD8ijfh5GBA",

                   "Zc5bQJFQVMe","iBdH17KZFDa",

                   "NZUXOvewqb7","Gbs2NVxHB7J",

                   "lMI5o6GHqEO","DGXFgqkLSxg",

                   "zVKezSVdQF2","A3LtzuWlBzf",

                   "bLlTB7GslyC","ZvU4dIng8HA",

                   "gCfjH0VC3Nq","msf7TrM88HJ",

                   "P7hl1qbQMos","oBbA8EeWvOy",

                   "IFsTVc7Ikzv","rYCvi2Nycdn",

                   "eOc5QwUkILS","a5reJaYN7JO",

                   "UnZ4pd6jreF","q8EPXzyFG3m",

                   "gQiP4nWxfDX", "NKeGeIRTju0",

                   "jfF8v5nIjU2","zwvAVu1Eaf8",

                   "bngER8Yhw8d","IoXvuY1hlJm",

                   "Zi4NBqbjQS6","iA2CIyjssXZ"
];