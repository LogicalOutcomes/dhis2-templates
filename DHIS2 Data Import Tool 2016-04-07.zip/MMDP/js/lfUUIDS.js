/** Property file for the dataElements and OptionCombo for LF worksheet */

var categoryLFCombo = "INgVh9IjrCz";
var lfSectionA = ["r5LVxFVlkg6", "ZI3jx5ULrku", "xy12Iq4vNXE", "V3sRcK3BhQf", "pw6s2cLRkGJ", "UEpBYAvUbyG"];//oCombo INgVh9IjrCz
var lfSectionB = ["qYz4z2oQWxx", "jiBXGBdyvyc"];
var lfSectionC = ["CgFWJJj4S1K", "Jm67zAiOoR2", "Juefz3vvQCN", "VbgS8laukDb", "YmxKJomPdtE", "ImVAKgaOsoH", "mdCC3TQvDLM", "jBh8xojsZXn", "yt3qrG6nkyO",
    "dcRNXYTdkNo", "YBNlk1Yqzhg", "PiIliKLGelc", "OwCJ3KbygPS", "XpB5SWv9Euf"];

var optionComboLFSectionB = ["BO4L7pJFvEB", "zIg55R6iza0"];