/** Property file for the dataElements and OptionCombo for TT worksheet */
var categoryCombo = "INgVh9IjrCz";
var dataElementSectionA = ["FnILRVcxLxD", "B5RFa4cGhdD", "ixaPRvF8D5c", "a3oOkmlPcCs", "qxGa4ZCcVVD", "o4440lD3ciB", "MW6JFIeivma", "JJGkqSTYjcO", "IsktQpW92Fq", "ZA1Kf83V1qp", "Ml58dhHBkb0", /*"Ob0d9VCfY6l" - Age and sex backlog,*/ "DX2EJGrX6G1", "PQqRcoZzk5Y", "edorry6lQwW", "Aofnljekwtc"];

var dataElementSectionB = ["NoR27SlCtsM", "sDFzdEJVKVY", "g7axvowdHGQ", "pcGkMZQhD5V", "XMhRAWHyYPT", "agN2uDyrfHc", "LYWMWtrmhUT", "DNfFxn4Yn5h"];

//                                                                                                                                                  BF
var dataElementSectionC = ["HquwKcwGZxY", "MHST8iOR2b0", "KnqK8C6xnib", "uwNulyGuvhX", "HyFDIw9EWIT", "Qi2o3x9iW8Y", "Nd2C1kk9Iyc", "GQKZ4OhUhqt", "pFRc8h0hQXY", "o29hIFAbnbC","ER4ToNlmnwd","Txn5Vzr2h6h","vZhK7b4KTDv", "HiiFcmN49ps"];

//Male           //Female
var optionComboGender = ["BO4L7pJFvEB", "zIg55R6iza0"];


incountryPartners = {
    "HKI":"ToT32",
    "HI":"ToT35",
    "World Bank":"ToT41",
    "Autre":"ToT36",
    "Sightsavers":"ToT37",
    "FHF":"ToT34",
    "LFTW":"ToT39",
    "RTI":"ToT40",
    "Other":"ToT41",
    "No value":"No value"
}


