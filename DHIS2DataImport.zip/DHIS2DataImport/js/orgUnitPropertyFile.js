/** Property file for the organisation units and there corresponding DHIS2 UUID */
orgUnits = {
    "Country 1": "Lt9iRtYewIY",
    "Country 2": "VJK9udE6Pss",
    "Country 3": "l5sBg5k4c5E"

    /** Add in more Orgunits here */
}